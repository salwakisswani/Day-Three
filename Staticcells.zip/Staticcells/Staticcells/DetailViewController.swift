//
//  DetailViewController.swift
//  TableViewTutorial
//
//  Created by MAC on 6/20/19.
//  Copyright © 2019 PaulRenfrew. All rights reserved.
//

import UIKit

protocol DetailViewControllerDelegate: class {
  func didUpdateValue(to string: String)
}

class DetailViewController: UIViewController {
  @IBOutlet weak var theTextfield: UITextField!
  
  var stringToShow: String?
  var delegate: DetailViewControllerDelegate?
  
  override func viewDidLoad() {
    super.viewDidLoad()
    theTextfield.text = stringToShow
  }
  
  @IBAction func submitNewValue(_ sender: Any) {
    self.delegate?.didUpdateValue(to: theTextfield.text!)
    navigationController?.popViewController(animated: true)
  }
}
