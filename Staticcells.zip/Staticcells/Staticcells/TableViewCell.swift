//
//  TableViewCell.swift
//  TableViewTutorial
//
//  Created by MAC on 6/20/19.
//  Copyright © 2019 PaulRenfrew. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell {
  
  @IBOutlet weak var theLabel: UILabel!
}
