//
//  ViewController.swift
//  Staticcells
//
//  Created by Admin on 6/21/19.
//  Copyright © 2019 Salwa Kisswani. All rights reserved.
//

import UIKit

    class ViewController: UIViewController {
        
       
        
override func viewDidLoad() {
            super.viewDidLoad()
            // Do any additional setup after loading the view.
}
}

 class TableView: UITableViewController{
    
override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    return 5
}


override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
    
    return cell
}

}



